// ============================================================
//  🔥 Firebase Config
//  روح Firebase Console وانشئ مشروع جديد، وبعدين
//  حط بيانات مشروعك هنا
//  https://console.firebase.google.com
// ============================================================

import { initializeApp } from 'firebase/app'
import { getFirestore }  from 'firebase/firestore'

// ✏️ استبدل البيانات دي ببيانات مشروعك من Firebase Console
const firebaseConfig = {
  apiKey:            'YOUR_API_KEY',
  authDomain:        'YOUR_PROJECT.firebaseapp.com',
  projectId:         'YOUR_PROJECT_ID',
  storageBucket:     'YOUR_PROJECT.appspot.com',
  messagingSenderId: 'YOUR_SENDER_ID',
  appId:             'YOUR_APP_ID',
}

const app = initializeApp(firebaseConfig)
export const db = getFirestore(app)
