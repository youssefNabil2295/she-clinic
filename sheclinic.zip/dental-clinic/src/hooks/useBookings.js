// src/hooks/useBookings.js
// ── كل منطق الحجوزات مع Firebase ────────────────────────

import { useState, useEffect } from 'react'
import {
  collection, addDoc, getDocs,
  query, where, serverTimestamp,
} from 'firebase/firestore'
import { db } from '../firebase/config'

const COLLECTION = 'bookings'

export function useBookings() {
  const [bookedSlots, setBookedSlots] = useState([])  // ['2025-06-15_10:00 AM', ...]
  const [loading,     setLoading]     = useState(false)
  const [error,       setError]       = useState(null)

  // ── تحميل الحجوزات الموجودة ──────────────────────────
  async function fetchBookedSlots(date) {
    if (!date) return
    try {
      const q   = query(collection(db, COLLECTION), where('date', '==', date))
      const snap = await getDocs(q)
      const slots = snap.docs.map(d => d.data().time)
      setBookedSlots(slots)
    } catch (e) {
      console.error('fetchBookedSlots error:', e)
    }
  }

  // ── إضافة حجز جديد ───────────────────────────────────
  async function addBooking(formData) {
    setLoading(true)
    setError(null)
    try {
      // تحقق إن الوقت مش محجوز
      const q    = query(
        collection(db, COLLECTION),
        where('date', '==', formData.date),
        where('time', '==', formData.time),
      )
      const snap = await getDocs(q)
      if (!snap.empty) {
        setError('This appointment is already booked — please select another time.')
        setLoading(false)
        return false
      }

      // احفظ الحجز
      await addDoc(collection(db, COLLECTION), {
        ...formData,
        createdAt: serverTimestamp(),
      })

      // حدّث القائمة المحلية
      setBookedSlots(prev => [...prev, formData.time])
      setLoading(false)
      return true
    } catch (e) {
      setError('Something went wrong. Please try again.')
      setLoading(false)
      return false
    }
  }

  return { bookedSlots, loading, error, setError, fetchBookedSlots, addBooking }
}
