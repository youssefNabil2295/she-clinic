// src/components/About.jsx
import { useLang } from '../context/LangContext'
import { DOCTOR, IMAGES, UI } from '../data/content'

export default function About() {
  const { lang, isAr } = useLang()
  return (
    <>
      <div className="gold-divider" />
      <section id="about" className="bg-white py-16 md:py-20">
        <div className="max-w-6xl mx-auto px-6 grid md:grid-cols-2 gap-12 items-center">
          <div className={isAr ? 'order-2 text-right' : 'order-1'}>
            <h2 className="text-2xl md:text-3xl font-bold text-navy mb-4">{UI.aboutTitle[lang]}</h2>
            <p className="text-navy/60 leading-relaxed text-sm md:text-base">{DOCTOR.about[lang]}</p>
          </div>
          <div className={isAr ? 'order-1' : 'order-2'}>
            <img src={IMAGES.doctorAbout} alt={DOCTOR.name[lang]}
              className="w-full h-72 md:h-80 object-cover rounded-xl shadow-xl"
              onError={e => { e.target.style.display='none'; e.target.nextSibling.style.display='flex' }}
            />
            <div className="w-full h-72 md:h-80 rounded-xl shadow-xl items-center justify-center text-8xl"
              style={{ display:'none', background:'linear-gradient(135deg,#C8DFF0,#DDEAF5)' }}>
              👨‍⚕️
            </div>
          </div>
        </div>
      </section>
      <div className="gold-divider" />
    </>
  )
}
