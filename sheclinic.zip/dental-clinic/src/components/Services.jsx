// src/components/Services.jsx
import { useLang } from '../context/LangContext'
import { SERVICES, UI } from '../data/content'

export default function Services() {
  const { lang, isAr } = useLang()
  return (
    <section id="services" className="bg-offwhite py-16 md:py-20">
      <div className="max-w-6xl mx-auto px-6">
        {/* عنوان */}
        <div className="section-title-line mb-10">
          <h2 className="text-2xl md:text-3xl font-bold text-navy whitespace-nowrap">
            {UI.servicesTitle[lang]}
          </h2>
        </div>

        {/* كاردات */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-5">
          {SERVICES.map(s => (
            <div key={s.id}
              className={`bg-white border-2 border-gold/40 rounded-xl p-5 text-center cursor-pointer
                hover:border-gold hover:shadow-lg hover:-translate-y-1 transition-all duration-200
                ${isAr ? 'text-right' : 'text-left'}`}>
              <span className="text-4xl block mb-3">{s.icon}</span>
              <h3 className="font-bold text-navy text-sm md:text-base mb-2">{s.name[lang]}</h3>
              <p className="text-navy/50 text-xs md:text-sm leading-relaxed">{s.desc[lang]}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
