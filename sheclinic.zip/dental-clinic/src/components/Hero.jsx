// src/components/Hero.jsx
import { useLang } from '../context/LangContext'
import { DOCTOR, IMAGES, UI } from '../data/content'

export default function Hero() {
  const { lang, isAr } = useLang()

  function scrollTo(hash) {
    document.getElementById(hash)?.scrollIntoView({ behavior: 'smooth' })
  }

  return (
    <section id="hero" className="relative min-h-[420px] md:min-h-[480px] overflow-hidden pt-16"
      style={{ background: 'linear-gradient(to left, #C8DFF0 0%, #DDEAF5 30%, #EEF4FB 60%, #F4F6FA 100%)' }}>

      <div className="max-w-6xl mx-auto px-6 h-full flex items-center py-16 md:py-20">
        <div className={`max-w-md z-10 relative ${isAr ? 'text-right' : 'text-left'}`}>
          <h1 className="text-3xl md:text-4xl font-extrabold text-navy leading-tight mb-3">
            {DOCTOR.title[lang]}
          </h1>
          <p className="text-navy/60 text-base md:text-lg mb-8 font-medium">
            {DOCTOR.subtitle[lang]}
          </p>
          <button onClick={() => scrollTo('booking')}
            className="inline-flex items-center gap-2 bg-gradient-to-r from-gold to-gold-light text-navy font-bold px-7 py-3 rounded-lg shadow-lg hover:-translate-y-1 hover:shadow-xl transition-all text-sm md:text-base">
            📅 {UI.bookNow[lang]}
          </button>
        </div>
      </div>

      {/* صورة الدكتور */}
      <div className={`absolute ${isAr ? 'right-1/3' : 'left-1/3'} top-0 bottom-0 ${isAr ? 'left-0' : 'right-0'} flex items-end justify-center overflow-hidden`}>
        <img src={IMAGES.doctorHero} alt="Doctor"
          className="h-full object-cover object-top"
          onError={e => { e.target.style.display='none'; e.target.nextSibling.style.display='flex' }}
        />
        <div className="hidden w-72 h-full items-end justify-center text-[8rem] pb-4" style={{display:'none'}}>
          👩‍⚕️
        </div>
      </div>

      {/* موجة */}
      <div className="absolute bottom-0 left-0 right-0">
        <svg viewBox="0 0 1440 60" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="none" className="w-full h-10 md:h-14">
          <path d="M0,30 C360,60 1080,0 1440,30 L1440,60 L0,60 Z" fill="#F4F6FA"/>
        </svg>
      </div>
    </section>
  )
}
