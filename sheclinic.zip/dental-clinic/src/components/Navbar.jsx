// src/components/Navbar.jsx
import { useState, useEffect } from 'react'
import { useLang } from '../context/LangContext'
import { DOCTOR, NAV_LINKS } from '../data/content'

export default function Navbar() {
  const { lang, isAr, toggle } = useLang()
  const [scrolled, setScrolled] = useState(false)
  const [menuOpen, setMenuOpen] = useState(false)

  useEffect(() => {
    const fn = () => setScrolled(window.scrollY > 20)
    window.addEventListener('scroll', fn)
    return () => window.removeEventListener('scroll', fn)
  }, [])

  function scrollTo(hash) {
    setMenuOpen(false)
    document.getElementById(hash)?.scrollIntoView({ behavior: 'smooth' })
  }

  return (
    <header className={`fixed top-0 inset-x-0 z-50 transition-all duration-300 bg-white border-b-2 border-gold ${scrolled ? 'shadow-md' : ''}`}>
      <div className="max-w-6xl mx-auto px-6 h-16 flex items-center justify-between">

        {/* اللوجو */}
        <button onClick={() => scrollTo('hero')} className="font-bold text-navy text-lg hover:text-gold transition-colors">
          {DOCTOR.name[lang]}
        </button>

        {/* روابط Desktop */}
        <nav className="hidden md:flex items-center gap-8">
          {NAV_LINKS.map(l => (
            <button key={l.hash} onClick={() => scrollTo(l.hash)}
              className="text-navy/70 hover:text-navy text-sm font-medium transition-colors pb-0.5 hover:border-b-2 hover:border-navy">
              {l[lang]}
            </button>
          ))}
        </nav>

        {/* زرار اللغة + حجز */}
        <div className="flex items-center gap-3">
          {/* زرار تغيير اللغة */}
          <button
            onClick={toggle}
            className="border border-gold text-gold font-bold text-xs px-3 py-1.5 rounded-lg hover:bg-gold hover:text-navy transition-all"
          >
            {isAr ? 'EN' : 'عربي'}
          </button>

          <button onClick={() => scrollTo('booking')}
            className="hidden md:flex items-center gap-2 bg-gradient-to-r from-gold to-gold-light text-navy font-bold text-sm px-5 py-2 rounded-lg shadow hover:-translate-y-0.5 transition-all">
            📅 {isAr ? 'احجز الآن' : 'Book Now'}
          </button>

          {/* Hamburger */}
          <button onClick={() => setMenuOpen(!menuOpen)} className="md:hidden flex flex-col gap-1.5 p-1">
            <span className={`block w-5 h-0.5 bg-navy transition-all ${menuOpen ? 'rotate-45 translate-y-2' : ''}`} />
            <span className={`block w-5 h-0.5 bg-navy transition-all ${menuOpen ? 'opacity-0' : ''}`} />
            <span className={`block w-5 h-0.5 bg-navy transition-all ${menuOpen ? '-rotate-45 -translate-y-2' : ''}`} />
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {menuOpen && (
        <div className="md:hidden bg-white border-t border-gold/30 px-6 py-5 flex flex-col gap-4">
          {NAV_LINKS.map(l => (
            <button key={l.hash} onClick={() => scrollTo(l.hash)}
              className={`${isAr ? 'text-right' : 'text-left'} text-navy/80 hover:text-navy font-medium`}>
              {l[lang]}
            </button>
          ))}
          <button onClick={() => scrollTo('booking')}
            className="bg-gradient-to-r from-gold to-gold-light text-navy font-bold text-sm px-5 py-2.5 rounded-lg text-center">
            📅 {isAr ? 'احجز الآن' : 'Book Now'}
          </button>
        </div>
      )}
    </header>
  )
}
