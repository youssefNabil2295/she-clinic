// src/data/content.js
// ============================================================
//  📝 ملف البيانات — كل التعديلات هنا
// ============================================================

export const DOCTOR = {
  name:    { en: 'Dr. Your Name',     ar: 'د. اسمك هنا' },
  title:   { en: 'Professional Dental Care',  ar: 'رعاية أسنان احترافية' },
  subtitle:{ en: 'Healthy Smile Starts Here', ar: 'ابتسامتك الصحية تبدأ من هنا' },
  about:   {
    en: 'Experienced and dedicated dentist providing top-quality care for all your dental needs. With over 10 years of experience, we ensure your smile is in the best hands.',
    ar: 'طبيب أسنان متخصص وملتزم بتقديم أعلى مستوى من الرعاية لجميع احتياجاتك. بخبرة تزيد عن ١٠ سنوات، ابتسامتك بين أيدٍ أمينة.',
  },
  phone:   '201XXXXXXXXX',
  address: { en: '123 Dental St, City', ar: '١٢٣ شارع الأسنان، المدينة' },
  hours:   { en: 'Sat – Thu: 10AM – 9PM', ar: 'السبت – الخميس: ١٠ص – ٩م' },
  email:   'info@dentalclinic.com',
  instagram: 'https://instagram.com/YOUR_USERNAME',
  facebook:  'https://facebook.com/YOUR_USERNAME',
}

export const IMAGES = {
  heroBg:      '/images/hero-bg.jpg',
  doctorHero:  '/images/doctor-hero.png',
  doctorAbout: '/images/doctor-about.jpg',
}

export const SERVICES = [
  { id: 1, icon: '✨', name: { en: 'Teeth Whitening', ar: 'تبييض الأسنان' }, desc: { en: 'Professional whitening for a brighter smile.', ar: 'تبييض احترافي لابتسامة أكثر إشراقاً.' } },
  { id: 2, icon: '🦴', name: { en: 'Dental Implants', ar: 'زراعة الأسنان' }, desc: { en: 'Permanent tooth replacement solutions.',        ar: 'حلول دائمة لتعويض الأسنان المفقودة.' } },
  { id: 3, icon: '🦷', name: { en: 'Orthodontics',    ar: 'تقويم الأسنان' }, desc: { en: 'Braces and aligners for a perfect smile.',    ar: 'تقويم ثابت ومتحرك لابتسامة مثالية.' } },
  { id: 4, icon: '🔬', name: { en: 'Root Canal',      ar: 'علاج العصب'    }, desc: { en: 'Pain-free root canal treatment.',              ar: 'علاج عصب بدون ألم بأحدث التقنيات.' } },
]

export const NAV_LINKS = [
  { hash: 'hero',     en: 'Home',     ar: 'الرئيسية' },
  { hash: 'about',    en: 'About',    ar: 'عن الدكتور' },
  { hash: 'services', en: 'Services', ar: 'الخدمات' },
  { hash: 'booking',  en: 'Booking',  ar: 'الحجز' },
]

export const TIME_SLOTS = [
  '09:00 AM','10:00 AM','11:00 AM',
  '12:00 PM','01:00 PM','02:00 PM',
  '03:00 PM','04:00 PM','05:00 PM',
  '06:00 PM','07:00 PM','08:00 PM',
]

export const UI = {
  bookNow:          { en: 'Book Now',                   ar: 'احجز الآن' },
  aboutTitle:       { en: 'About the Doctor',           ar: 'عن الدكتور' },
  servicesTitle:    { en: 'Our Services',               ar: 'خدماتنا' },
  bookingTitle:     { en: 'Book Appointment',           ar: 'احجز موعد' },
  bookingBtn:       { en: 'Book via WhatsApp',          ar: 'احجز عبر واتساب' },
  namePlaceholder:  { en: 'Your Name',                  ar: 'اسمك' },
  phonePlaceholder: { en: 'Phone Number',               ar: 'رقم الهاتف' },
  selectDate:       { en: 'Select Date',                ar: 'اختر التاريخ' },
  selectTime:       { en: 'Select Time',                ar: 'اختر الوقت' },
  selectService:    { en: 'Select Service',             ar: 'اختر الخدمة' },
  alreadyBooked:    { en: 'This appointment is already booked — please select another time.', ar: 'هذا الموعد محجوز بالفعل — من فضلك اختر وقتاً آخر.' },
  successMsg:       { en: 'Opening WhatsApp with your booking details!', ar: 'جاري فتح واتساب مع تفاصيل حجزك!' },
  required:         { en: 'This field is required.',    ar: 'هذا الحقل مطلوب.' },
  footerCopy:       { en: '© Dental Clinic — All Rights Reserved', ar: '© عيادة الأسنان — جميع الحقوق محفوظة' },
}
