// src/context/LangContext.jsx
import { createContext, useContext, useState } from 'react'

const LangContext = createContext()

export function LangProvider({ children }) {
  const [lang, setLang] = useState('en') // 'en' | 'ar'
  const isAr = lang === 'ar'

  function toggle() {
    setLang(l => l === 'en' ? 'ar' : 'en')
    document.documentElement.dir  = lang === 'en' ? 'rtl' : 'ltr'
    document.documentElement.lang = lang === 'en' ? 'ar'  : 'en'
  }

  return (
    <LangContext.Provider value={{ lang, isAr, toggle }}>
      {children}
    </LangContext.Provider>
  )
}

export const useLang = () => useContext(LangContext)
