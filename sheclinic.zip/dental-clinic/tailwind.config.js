import { heroui } from '@heroui/react'

/** @type {import('tailwindcss').Config} */
export default {
  content: [
    './index.html',
    './src/**/*.{js,jsx}',
    './node_modules/@heroui/theme/dist/**/*.{js,ts,jsx,tsx}',
  ],
  theme: {
    extend: {
      colors: {
        navy:  { DEFAULT: '#1B2B4A', soft: '#243354', mid: '#2E3F62' },
        gold:  { DEFAULT: '#C9A84C', light: '#D4B460', pale: '#F0D98A' },
        offwhite: '#F4F6FA',
      },
      fontFamily: {
        sans: ['Inter', 'Cairo', 'sans-serif'],
      },
    },
  },
  darkMode: 'class',
  plugins: [heroui()],
}
